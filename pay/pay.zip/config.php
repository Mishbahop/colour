<?php
return [
    'db_host' => 'localhost',       
    'db_user' => 'djvqcjwh_bdgwin',  
    'db_pass' => 'djvqcjwh_bdgwin',  
    'db_name' => 'djvqcjwh_bdgwin',
    'api_url' => 'https://www.lg-pay.com/api/order/create',
    'secret_key' => '9tzxJChPAmmypU33',
    'app_id' => 'YD3027',
    'name' => 'bdgwinbet.site',
];
